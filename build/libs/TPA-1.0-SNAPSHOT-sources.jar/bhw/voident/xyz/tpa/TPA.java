package bhw.voident.xyz.tpa;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_2186;
import net.minecraft.class_2338;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_5250;
import net.minecraft.server.MinecraftServer;
import net.minecraft.text.*;
import com.mojang.brigadier.arguments.StringArgumentType;
import java.util.*;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public class TPA implements ModInitializer {

    private static final Map<UUID, UUID> requests = new HashMap<>();
    private static final Map<UUID, class_2338> frozen = new HashMap<>();
    private static final Map<UUID, Integer> countdown = new HashMap<>();
    private static final Map<UUID, class_2338> targetPos = new HashMap<>();
    private static final Set<UUID> toggleOff = new HashSet<>();

    // 家庭功能
    private static final Map<UUID, Map<String, class_2338>> homes = new HashMap<>();
    // 死亡回点
    private static final Map<UUID, class_2338> deathBack = new HashMap<>();

    @Override
    public void onInitialize() {

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {

            // ---------------------- TPA ----------------------
            dispatcher.register(method_9247("tpa").then(method_9244("player", class_2186.method_9305()).executes(c -> {
                class_3222 sender = c.getSource().method_44023();
                class_3222 target = class_2186.method_9315(c, "player");
                if (sender == null || target == null) return 1;

                if (sender.method_5667().equals(target.method_5667())) {
                    sender.method_43496(class_2561.method_43470("你不能向自己传送"));
                    return 1;
                }

                if (toggleOff.contains(target.method_5667())) {
                    sender.method_43496(class_2561.method_43470("对方关闭了 TPA"));
                    return 1;
                }

                requests.put(sender.method_5667(), target.method_5667());

                sender.method_43496(class_2561.method_43470("已向 " + target.method_5477().getString() + " 发送请求"));

                class_5250 accept = class_2561.method_43470("[ 接受 ]")
                        .method_27692(class_124.field_1060)
                        .method_27694(s -> s.method_10958(new class_2558(class_2558.class_2559.field_11750, "/tpaaccept")));

                class_5250 deny = class_2561.method_43470("[ 拒绝 ]")
                        .method_27692(class_124.field_1061)
                        .method_27694(s -> s.method_10958(new class_2558(class_2558.class_2559.field_11750, "/tpadeny")));

                target.method_43496(class_2561.method_43470(sender.method_5477().getString() + " 想传送到你"));
                target.method_43496(accept.method_10852(class_2561.method_43470(" ")).method_10852(deny));

                return 1;
            })));

            dispatcher.register(method_9247("tpaaccept").executes(c -> {
                class_3222 b = c.getSource().method_44023();
                if (b == null) return 1;

                UUID from = requests.entrySet().stream()
                        .filter(e -> e.getValue().equals(b.method_5667()))
                        .map(Map.Entry::getKey)
                        .findFirst().orElse(null);

                if (from == null) {
                    b.method_43496(class_2561.method_43470("没有请求"));
                    return 1;
                }

                class_3222 a = b.method_5682().method_3760().method_14602(from);
                if (a == null) return 1;

                targetPos.put(from, b.method_24515()); // 锁定接受瞬间坐标

                a.method_43496(class_2561.method_43470(b.method_5477().getString() + " 接受了你的请求"));
                b.method_43496(class_2561.method_43470("已接受"));

                startTeleport(a);
                return 1;
            }));

            dispatcher.register(method_9247("tpadeny").executes(c -> {
                class_3222 b = c.getSource().method_44023();
                if (b == null) return 1;

                requests.entrySet().removeIf(e -> {
                    if (e.getValue().equals(b.method_5667())) {
                        class_3222 a = b.method_5682().method_3760().method_14602(e.getKey());
                        if (a != null) a.method_43496(class_2561.method_43470("对方拒绝了你的请求"));
                        return true;
                    }
                    return false;
                });

                b.method_43496(class_2561.method_43470("已拒绝"));
                return 1;
            }));

            // ---------------------- Home 功能 ----------------------
            dispatcher.register(method_9247("sethome").then(method_9244("name", StringArgumentType.word()).executes(c -> {
                class_3222 player = c.getSource().method_44023();
                if (player == null) return 1;

                String name = StringArgumentType.getString(c, "name");

                homes.putIfAbsent(player.method_5667(), new HashMap<>());
                Map<String, class_2338> playerHomes = homes.get(player.method_5667());

                if (playerHomes.containsKey(name)) {
                    player.method_43496(class_2561.method_43470("家已经存在: " + name).method_27692(class_124.field_1061));
                    return 1;
                }

                playerHomes.put(name, player.method_24515());
                player.method_43496(class_2561.method_43470("已创建家: " + name).method_27692(class_124.field_1060));
                return 1;
            })));

            dispatcher.register(method_9247("delhome").then(method_9244("name", StringArgumentType.word()).executes(c -> {
                class_3222 player = c.getSource().method_44023();
                if (player == null) return 1;

                String name = StringArgumentType.getString(c, "name");
                Map<String, class_2338> playerHomes = homes.get(player.method_5667());
                if (playerHomes == null || !playerHomes.containsKey(name)) {
                    player.method_43496(class_2561.method_43470("没有找到家: " + name).method_27692(class_124.field_1061));
                    return 1;
                }

                playerHomes.remove(name);
                player.method_43496(class_2561.method_43470("已删除家: " + name).method_27692(class_124.field_1060));
                return 1;
            })));

            dispatcher.register(method_9247("home").then(method_9244("name", StringArgumentType.word()).suggests((c, builder) -> {
                class_3222 player = c.getSource().method_44023();
                if (player == null) return builder.buildFuture();

                Map<String, class_2338> playerHomes = homes.get(player.method_5667());
                if (playerHomes != null) {
                    for (String name : playerHomes.keySet()) builder.suggest(name);
                }
                return builder.buildFuture();
            }).executes(c -> {
                class_3222 player = c.getSource().method_44023();
                if (player == null) return 1;

                String name = StringArgumentType.getString(c, "name");
                Map<String, class_2338> playerHomes = homes.get(player.method_5667());

                if (playerHomes == null || !playerHomes.containsKey(name)) {
                    player.method_43496(class_2561.method_43470("没有找到家: " + name).method_27692(class_124.field_1061));
                    return 1;
                }

                targetPos.put(player.method_5667(), playerHomes.get(name));
                startTeleport(player);
                return 1;
            })));

            // ---------------------- Death / Back ----------------------
            // 玩家死亡事件监听，用于设置 deathBack
            // 这里示例用 Fabric 内置事件，需要你在外部注册 PlayerDeathCallback 之类
            // 假设已经监听了死亡，并调用 recordDeath(player)
            dispatcher.register(method_9247("back").executes(c -> {
                class_3222 player = c.getSource().method_44023();
                if (player == null) return 1;

                class_2338 pos = deathBack.get(player.method_5667());
                if (pos == null) {
                    player.method_43496(class_2561.method_43470("没有死亡回点").method_27692(class_124.field_1061));
                    return 1;
                }

                targetPos.put(player.method_5667(), pos);
                startTeleport(player);
                return 1;
            }));

        });

        ServerTickEvents.END_SERVER_TICK.register(this::tick);
    }

    // 玩家死亡时调用
    public static void recordDeath(class_3222 player) {
        if (player == null) return;
        deathBack.put(player.method_5667(), player.method_24515());
        player.method_43496(class_2561.method_43470("你死亡了，可使用 /back 回到死亡地点").method_27692(class_124.field_1061));
    }

    private void startTeleport(class_3222 p) {
        frozen.put(p.method_5667(), p.method_24515());
        countdown.put(p.method_5667(), 100); // 5秒 = 100tick
        p.method_7353(class_2561.method_43470("正在传送 5").method_27692(class_124.field_1060), true);
    }

    private void tick(MinecraftServer s) {
        Iterator<UUID> it = countdown.keySet().iterator();

        while (it.hasNext()) {
            UUID u = it.next();
            class_3222 p = s.method_3760().method_14602(u);
            if (p == null) {
                it.remove();
                frozen.remove(u);
                targetPos.remove(u);
                continue;
            }

            class_2338 f = frozen.get(u);
            if (!p.method_24515().equals(f)) {
                p.method_7353(class_2561.method_43470("你移动了，传送已取消").method_27692(class_124.field_1061), true);
                p.method_5783(class_3417.field_15075, 2f, 1f);

                it.remove();
                frozen.remove(u);
                targetPos.remove(u);
                continue;
            }

            int t = countdown.get(u) - 1;
            countdown.put(u, t);

            if (t % 20 == 0) {
                p.method_7353(class_2561.method_43470("正在传送 " + t / 20).method_27692(class_124.field_1060), true);
                p.method_5783(class_3417.field_14622.comp_349(), 1, 1);
            }

            if (t <= 0) {
                class_2338 tp = targetPos.get(u);
                if (tp != null) {
                    p.method_14251(p.method_51469(), tp.method_10263(), tp.method_10264(), tp.method_10260(), p.method_36454(), p.method_36455());
                }

                it.remove();
                frozen.remove(u);
                targetPos.remove(u);
            }
        }
    }
}
